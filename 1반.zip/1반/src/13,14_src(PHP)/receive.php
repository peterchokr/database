<?php
	$userID = $_POST["userID"];
	$userName = $_POST["userName"];
	
	echo "전달 받은 아이디 : ", $userID, "<br>";
	echo "전달 받은 이름 : ",$userName, "<br>";
 ?>