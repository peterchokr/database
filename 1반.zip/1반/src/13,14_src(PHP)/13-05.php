﻿<?php 
   $str1 = "IT CookBook. MySQL<br>";   echo $str1;
   $str2 = 'PHP 프로그래밍<br>';   echo $str2;
   $str3 = "SELECT * FROM userTBL WHERE userID='KHD' ";   echo $str3;
 ?>