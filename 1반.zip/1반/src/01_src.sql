/* 01장 */


-- p.25 MySQL Community 8.0 설치하기

-- p.41 MySQL의 실행 파일에 있는 경로를 Path에 추가하기
/* 
SETX PATH "%PATH%;C:\Program Files\MySQL\MySQL Server 8.0\bin" /M 

shutdown -r -t 0 
*/

-- p.43 샘플 데이터베이스를 MySQL로 가져오기 

/*
cmd 
CD \employees 
mysql -u root -p 
source employees.sql ;
show databases ;
exit 
*/
