/* 03장 */

-- <실습> MySQL Workbench는 자체적으로 모델링 툴 제공해 준다.  



